import ActionsType from "../utils/actions.type"

export const setLoader = (value) => ({
  type: ActionsType.SET_LOADER,
  payload: value
});

export const setChooseType = (value) => ({
  type: ActionsType.SET_CHOOSED_TYPE,
  payload: value
});







