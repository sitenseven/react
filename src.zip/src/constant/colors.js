const COLORS = {
  primary: '#F9F9F9',
  secondary: '#000000',
  pinkyShade: '#6A82FB',
  primaryLight: '#11A7FF',
  danger: '#fd264d',
  gray: '#E4E7EC',
  grayLight: '#C2C7CF',
  G1Color: "#3B5998",
  G2Color: "#0D6B93",
  G3Color: "#235496",
};

export { COLORS };
