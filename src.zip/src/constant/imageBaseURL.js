export const ImageUrl = "https://sporforya.s3.us-east-2.amazonaws.com/";
