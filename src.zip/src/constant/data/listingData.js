export const sport = [

    {
        id: 'Aikido',
        name: 'Aikido'
    },
    {
        id: 'American football',
        name: 'American football'
    },
    {
        id: 'Angling',
        name: 'Angling'
    },
    {
        id: 'Archery',
        name: 'Archery'
    },
    {
        id: 'Athletics',
        name: 'Athletics'
    },
    {
        id: 'Australian rules football',
        name: 'Australian rules football'
    },
    {
        id: 'Badminton',
        name: 'Badminton'
    },
    {
        id: 'Ballroom dancing',
        name: 'Ballroom dancing'
    },
    {
        id: 'Baseball',
        name: 'Baseball'
    },
    {
        id: 'Basketball',
        name: 'Basketball'
    },
    {
        id: 'Bicycle polo',
        name: 'Bicycle polo'
    },
    {
        id: 'Billiards and snooker',
        name: 'Billiards and snooker'
    },
    {
        id: 'BMX',
        name: 'BMX'
    },
    {
        id: 'Bobsleigh',
        name: 'Bobsleigh'
    },
    {
        id: 'Boccia',
        name: 'Boccia'
    },
    {
        id: 'Bowls',
        name: 'Bowls'
    },
    {
        id: 'Boxing',
        name: 'Boxing'
    },
    {
        id: 'Canoeing',
        name: 'Canoeing'
    },
    {
        id: 'Caving',
        name: 'Caving'
    },
    {
        id: 'Cheerleading',
        name: 'Cheerleading'
    },
    {
        id: 'Chinese martial arts',
        name: 'Chinese martial arts'
    },
    {
        id: 'Clay pigeon shooting',
        name: 'Clay pigeon shooting'
    },
    {
        id: 'Climbing',
        name: 'Climbing'
    },
    {
        id: 'Cricket',
        name: 'Cricket'
    },
    {
        id: 'Croquet',
        name: 'Croquet'
    },
    {
        id: 'Curling',
        name: 'Curling'
    },
    {
        id: 'Cycling',
        name: 'Cycling'
    },
    {
        id: 'Dance, Ballet, Tap, HH',
        name: 'Dance, Ballet, Tap, HH'
    },
    {
        id: 'Darts',
        name: 'Darts'
    },
    {
        id: 'Disability sport',
        name: 'Disability sport'
    },
    {
        id: 'Diving',
        name: 'Diving'
    },
    {
        id: 'Dodgeball',
        name: 'Dodgeball'
    },
    {
        id: 'Dragon boat racing',
        name: 'Dragon boat racing'
    },
    {
        id: 'Duathlon',
        name: 'Duathlon'
    },
    {
        id: 'Equestrian',
        name: 'Equestrian'
    },
    {
        id: 'Exercise, movement and dance',
        name: 'Exercise, movement and dance'
    },
    {
        id: 'Fencing',
        name: 'Fencing'
    },
    {
        id: 'Fives',
        name: 'Fives'
    },
    {
        id: 'Folk dancing',
        name: 'Folk dancing'
    },
    {
        id: 'Football',
        name: 'Football'
    },
    {
        id: 'Futsal',
        name: 'Futsal'
    },
    {
        id: 'Gaelic football',
        name: 'Gaelic football'
    },
    {
        id: 'Gliding',
        name: 'Gliding'
    },
    {
        id: 'Golf',
        name: 'Golf'
    },
    {
        id: 'Gymnastics',
        name: 'Gymnastics'
    },
    {
        id: 'Handball',
        name: 'Handball'
    },
    {
        id: 'Hang gliding and paragliding',
        name: 'Hang gliding and paragliding'
    },
    {
        id: 'Highland games',
        name: 'Highland games'
    },
    {
        id: 'Hockey',
        name: 'Hockey'
    },
    {
        id: 'Horse Racing',
        name: 'Horse Racing'
    },
    {
        id: 'Horse Riding',
        name: 'Horse Riding'
    },
    {
        id: 'Hurling',
        name: 'Hurling'
    },
    {
        id: 'Ice hockey',
        name: 'Ice hockey'
    },
    {
        id: 'Ice skating',
        name: 'Ice skating'
    },
    {
        id: 'Jet skiing',
        name: 'Jet skiing'
    },
    {
        id: 'Ju jitsu',
        name: 'Ju jitsu'
    },
    {
        id: 'Judo',
        name: 'Judo'
    },
    {
        id: 'Karate',
        name: 'Karate'
    },
    {
        id: 'Keep fit',
        name: 'Keep fit'
    },
    {
        id: 'Kite Surfing',
        name: 'Kite Surfing'
    },
    {
        id: 'Lacrosse',
        name: 'Lacrosse'
    },
    {
        id: 'Luge',
        name: 'Luge'
    },
    {
        id: 'Model aircraft flying',
        name: 'Model aircraft flying'
    },
    {
        id: 'Modern pentathlon',
        name: 'Modern pentathlon'
    },
    {
        id: 'Motor cruising',
        name: 'Motor cruising'
    },
    {
        id: 'Motor cycling',
        name: 'Motor cycling'
    },
    {
        id: 'Motor sports',
        name: 'Motor sports'
    },
    {
        id: 'Mountain biking',
        name: 'Mountain biking'
    },
    {
        id: 'Mountaineering',
        name: 'Mountaineering'
    },
    {
        id: 'Movement and dance',
        name: 'Movement and dance'
    },
    {
        id: 'Netball',
        name: 'Netball'
    },
    {
        id: 'Orienteering',
        name: 'Orienteering'
    },
    {
        id: 'Parachuting',
        name: 'Parachuting'
    },
    {
        id: 'Petanque',
        name: 'Petanque'
    },
    {
        id: 'Polo',
        name: 'Polo'
    },
    {
        id: 'Powerboating',
        name: 'Powerboating'
    },
    {
        id: 'Powerlifting',
        name: 'Powerlifting'
    },

    {
        id: 'Puck hockey(roller)',
        name: 'Puck hockey(roller)'
    },
    {
        id: 'Racketball',
        name: 'Racketball'
    },
    {
        id: 'Rackets',
        name: 'Rackets'
    },
    {
        id: 'Rafting',
        name: 'Rafting'
    },

    {
        id: 'Rambling',
        name: 'Rambling'
    },
    {
        id: 'Roller sports',
        name: 'Roller sports'
    },
    {
        id: 'Rounders',
        name: 'Rounders'
    },
    {
        id: 'Rowing',
        name: 'Rowing'
    },
    {
        id: 'Rugby league',
        name: 'Rugby league'
    },
    {
        id: 'Rugby union',
        name: 'Rugby union'
    },
    {
        id: 'Sailing and yachting',
        name: 'Sailing and yachting'
    },
    {
        id: 'Shooting, air, clay target, crossbow',
        name: 'Shooting, air, clay target, crossbow'
    },
    {
        id: 'Show jumping',
        name: 'Show jumping'
    },
    {
        id: 'Skateboarding',
        name: 'Skateboarding'
    },
    {
        id: 'Skater hockey(roller)',
        name: 'Skater hockey(roller)'
    },
    {
        id: 'Skiing',
        name: 'Skiing'
    },
    {
        id: 'Skipping',
        name: 'Skipping'
    },
    {
        id: 'Snooker',
        name: 'Snooker'
    },
    {
        id: 'Snowboarding',
        name: 'Snowboarding'
    },
    {
        id: 'Softball',
        name: 'Softball'
    },
    {
        id: 'Speed skating(roller)',
        name: 'Speed skating(roller)'
    },
    {
        id: 'Speedway',
        name: 'Speedway'
    },
    {
        id: 'Squash',
        name: 'Squash'
    },
    {
        id: 'Sub aqua',
        name: 'Sub aqua'
    },

    {
        id: 'Surf life saving',
        name: 'Surf life saving'
    },
    {
        id: 'Surfing',
        name: 'Surfing'
    },
    {
        id: 'Swimming and diving',
        name: 'Swimming and diving'
    },
    {
        id: 'Table tennis',
        name: 'Table tennis'
    },
    {
        id: 'Taekwondo',
        name: 'Taekwondo'
    },
    {
        id: 'Tennis',
        name: 'Tennis'
    }, 
    {
        id: 'Tenpin bowling',
        name: 'Tenpin bowling'
    },
    {
        id: 'Trampolining',
        name: 'Trampolining'
    },
    {
        id: 'Triathlon',
        name: 'Triathlon'
    },
    {
        id: 'Tug of war',
        name: 'Tug of war'
    },

    {
        id: 'Ultimate(frisbee)',
        name: 'Ultimate(frisbee)'
    },
    {
        id: 'Volleyball',
        name: 'Volleyball'
    },
    {
        id: 'Wakeboarding',
        name: 'Wakeboarding'
    },
    {
        id: 'Water polo',
        name: 'Water polo'
    },

    {
        id: 'Water skiing',
        name: 'Water skiing'
    },

    {
        id: 'Weightlifting',
        name: 'Weightlifting'
    },
    {
        id: 'Wheelchair basketball',
        name: 'Wheelchair basketball'
    },
    {
        id: 'Wheelchair rugby',
        name: 'Wheelchair rugby'
    },
    {
        id: 'Windsurfing',
        name: 'Windsurfing'
    },
    {
        id: 'Wrestling',
        name: 'Wrestling'
    },
    {
        id: 'Yoga',
        name: 'Yoga'
    },
];














