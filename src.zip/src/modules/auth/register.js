import React, { useState, useEffect } from 'react';
import { StyleSheet, View, Text, Image, ScrollView, Alert } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import { heightPercentageToDP as hp } from 'react-native-responsive-screen';
import { ButtonRegular } from '../../common/buttonRegular';
import { MyTextinput } from '../../common/textinput';
import { FONTS, ICONS } from '../../constant';
import { createAccount } from '../../redux/user/user.action';
import TNIndicator from '../../common/TNIndicator'
import { useDispatch, useSelector } from 'react-redux';
import { setLoader } from '../../redux/loader/loader.action';

export const Register = (props) => {
  const loader = useSelector(state => state.loader.loader)
  const dispatch = useDispatch()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')

  useEffect(() => {
    return () => {
    }
  }, [])

  const getEmail = (value) => {
    let removeSpace = value.replace(/ /g, '')
    setEmail(removeSpace)
  }
  const getPassword = (value) => {
    setPassword(value)
  }

  const createUser = async () => {
    let validate = await validateEmail()
    if (email == "") {
      Alert.alert("Email field should not be blank")
    } else if (!validate) {
      Alert.alert("Wrong email format")
    } else if (password == "") {
      Alert.alert("Password field should not be blank")
    } else {
      dispatch(setLoader(true))
      let data = {
        "email": email,
        "password": password
      }
      dispatch(createAccount(data, props.navigation))
      setEmail('');
      setPassword('')
    }
  }
  const validateEmail = async () => {
    const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
  }

  return (
    <LinearGradient
      colors={['#3B5998', '#0D6B93']}
      style={styles.linearGradient}>
      <ScrollView style={{ width: '100%' }} contentContainerStyle={{ width: '100%', alignItems: 'center' }} >
        <View style={{ width: '90%', marginTop: 96, alignItems: 'center' }}>
          <Image source={ICONS.signinLogo} style={{ height: 69, width: 96 }} />
        </View>
        <View style={{ marginTop: 33 }}>
          <Text style={styles.head}>Sign up</Text>
        </View>
        <View style={{ width: '90%', marginTop: 39 }}>
          <Text style={styles.field}>Email address</Text>
          <MyTextinput
            value={email}
            onChangeText={getEmail.bind(this)}
            secureTextEntry={false}
          />
        </View>
        <View style={{ width: '90%', marginTop: 23 }}>
          <Text style={styles.field}>Password</Text>
          <MyTextinput
            secureTextEntry={true}
            value={password}
            onChangeText={getPassword.bind(this)}
          />
        </View>
        <View style={{ height: hp('16') }} />
        <View style={styles.bottom}>
          <ButtonRegular title="Done" onClick={() => { createUser() }} />
        </View>
      </ScrollView>
      {
        loader
          ?
          <TNIndicator />
          :
          null
      }
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  main: {},
  linearGradient: {
    flex: 1,
    alignItems: 'center',
  },
  head: {
    fontFamily: FONTS.SFBold,
    fontSize: 36,
    color: 'white',
  },
  field: {
    fontSize: 14,
    fontFamily: FONTS.SFBold,
    color: 'white',
    marginBottom: 11,
  },
  bottom: {
    width: '90%',
  },
});
