import React, { useState, useEffect } from 'react';
import { SafeAreaView, StyleSheet, Text, Image, View } from 'react-native';
import { widthPercentageToDP } from 'react-native-responsive-screen';
import { ButtonRegular } from '../../../common/btnRegular';
import { MyTextinputMultiline } from '../../../common/textinputMultiline';
import { FONTS, ICONS } from '../../../constant';
import { CustomSlider } from '../../review/component/Slider';
import { SliderCounter } from '../../review/component/sliderCounter';
import Header from '../../../common/headerBLC'
import { useDispatch, useSelector } from 'react-redux'
import { setLoader } from '../../../redux/loader/loader.action'
import { uploadReview } from '../../../redux/user/user.action'
import TNIndicator from '../../../common/TNIndicator'



const ReviewProvider = ({ navigation, route }) => {
  const data = route.params.data
  const dispatch = useDispatch()
  const currentUser = useSelector(state => state.user.currentUser)
  const loader = useSelector(state => state.loader.loader)
  const token = useSelector(state => state.user.token)

  const [comments, setComments] = useState('');
  const [rating, setRating] = useState(0);

  var head = 'Review your Provider';
  var headDesc =
    'Share your experience with the Sporforya Community by giving a Review. Your feedback will be valuable to other users.';
  var s1 = 'Rate your experience with the Provider';
  var s2 =
    'Share your experience with the Provider, your feedback will be valuable to other Users.';
  var option1 = 'Couldve been better';
  var option2 = 'Wonderful';

  useEffect(() => {
    return () => {
    }
  }, [])


  function ratingHandler(r) {
    setRating(r);
  }

  const onSendReview = () => {
    if (comments == '') {
      alert("Comment field should not be blank");
    } else {
      navigation.navigate("thankyouUser")
      // dispatch(setLoader(true))
      // let tempData = {
      //   "senderId": currentUser._id,
      //   "reciverIds": data.reciverIds,
      //   "lisitngId": data.lisitngId,
      //   "comments": comments,
      //   "ratingScore": rating
      // }
      // dispatch(uploadReview(tempData, token, navigation))
    }
  }

  return (
    <SafeAreaView style={styles.main}>
      <Header navigation={navigation} label="Review Users" />
      <View style={{ width: '90%', marginTop: 18 }}>
        <Text style={styles.head}>{head}</Text>
      </View>
      <View style={{ width: '90%', marginTop: 8 }}>
        <Text style={styles.headDesc}>{headDesc}</Text>
      </View>
      <View style={{ width: '90%', marginTop: 24 }}>
        <Text style={styles.statement}>{s1}</Text>
      </View>
      <View
        style={{
          width: '90%',
          marginTop: 8,
          flexDirection: 'row',
          justifyContent: 'space-between',
          alignItems: 'center',
        }}>
        <Text style={styles.options}>{option1}</Text>
        <Text style={styles.options}>{option2}</Text>
      </View>
      <View style={{ width: '90%', marginTop: 3 }}>
        <CustomSlider onValueChange={ratingHandler} value={rating} />
        <SliderCounter current={parseInt(rating * 10)} />
      </View>
      <View style={{ width: '90%', marginTop: 24 }}>
        <Text style={styles.statement}>{s2}</Text>
      </View>
      <View style={{ width: '90%', marginTop: 24 }}>
        <MyTextinputMultiline
          style={{ height: 157 }}
          onChangeText={setComments}
        />
      </View>
      <View
        style={{
          width: '90%',
          marginTop: 24,
          justifyContent: 'flex-end',
          alignItems: 'flex-end',
        }}>
        <Text style={styles.options}>{comments.length}/1000</Text>
      </View>
      <View style={styles.bottonBtn}>
        <ButtonRegular blue title="Send Review" onClick={onSendReview} />
      </View>
      {
        loader
          ?
          <TNIndicator />
          :
          null
      }
    </SafeAreaView>
  );
};
export default ReviewProvider;

const styles = StyleSheet.create({
  main: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: '#F8FAFF',
  },
  head: {
    fontFamily: FONTS.SFSemiBold,
    fontSize: 26,
    color: 'black',
  },
  headDesc: {
    fontFamily: FONTS.SFRegular,
    fontSize: 14,
    color: '#707070',
  },
  statement: {
    fontFamily: FONTS.SFSemiBold,
    fontSize: 12,
    color: '#808080',
  },
  options: {
    fontFamily: FONTS.SFRegular,
    fontSize: 10,
    color: '#808080',
  },
  bottonBtn: {
    width: widthPercentageToDP('90'),
    position: 'absolute',
    alignItems: 'center',
    width: '80%',
    bottom: 20,
  },
});
