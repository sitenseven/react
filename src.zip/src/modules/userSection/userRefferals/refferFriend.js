import React from 'react'
import { StyleSheet, Text, View } from 'react-native'

const refferFriend = () => {
    return (
        <View style={{}} >
        </View>
    )
}

export default refferFriend

const styles = StyleSheet.create({
    
})
