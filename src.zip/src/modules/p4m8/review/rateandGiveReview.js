import React from 'react'
import { StyleSheet, Text, View } from 'react-native'
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen'
import Header from '../../../common/headerBL'
import ReviewItem from './components/reviewItem'


const rateandGiveReview = (props) => {
    return (
        <View style={styles.container} >
            <Header label={"Give a Review"} navigation={props.navigation} />
            <ReviewItem navigation={props.navigation} />
        </View>
    )
}

export default rateandGiveReview

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#FFFFFF',
        alignItems: 'center'
    }
})
