import React from 'react'
import { StyleSheet, Text, View } from 'react-native'
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen'
import Header from '../../../common/headerBL'
import { FONTS } from '../../../constant'
import ReviewItem from './components/recieveReviewItem'


const recieveReview = (props) => {
    return (
        <View style={styles.container} >
            <Header label={"Receive a Review"} navigation={props.navigation} />
            <View style={{ width: wp('90'), marginTop: 10, marginBottom: 10 }} >
                <Text style={styles.header} >Receive a Review</Text>
                <Text style={styles.description} >You can send request to receive your review from provider for the services, facilities and events you have booked for.</Text>
            </View>
            <ReviewItem navigation={props.navigation} />
        </View>
    )
}

export default recieveReview

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#FFFFFF',
        alignItems: 'center'
    },
    header: {
        color: '#000000',
        fontSize: wp('6'),
        fontFamily: FONTS.SFSemiBold,

    },
    description: {
        color: '#707070',
        fontSize: wp('3.5'),
        fontFamily: FONTS.SFRegular
    }
})
