import { ICONS } from '../../../constant';


export const usersList = [
    {
        id: '1',
        name: 'John Doe',
        src: ICONS.userIcon,
    },
    {
        id: '2',
        name: 'Sarah William',
        src: ICONS.userIcon,
    },
    {
        id: '3',
        name: 'John Doe',
        src: ICONS.userIcon,
    },
    {
        id: '4',
        name: 'Sarah William',
        src: ICONS.userIcon,
    },
    {
        id: '5',
        name: 'John Doe',
        src: ICONS.userIcon,
    },
    {
        id: '6',
        name: 'Sarah William',
        src: ICONS.userIcon,
    },
    {
        id: '7',
        name: 'John Doe',
        src: ICONS.userIcon,
    },
];
