export const MedicalCondition = [
    {
        id: 'Asthma',
        title: 'Asthma'
    },
    {
        id: 'Anxiety',
        title: 'Anxiety'
    },
]