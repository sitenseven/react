export const IssueType = [
    {
        id: 'My Account',
        name: 'My Account'
    },
    {
        id: 'Payments',
        name: 'Payments'
    },
    {
        id: 'Bookings',
        name: 'Bookings'
    },
    {
        id: 'Bug Report',
        name: 'Bug Report'
    },
    {
        id: 'General Inquiry',
        name: 'General Inquiry'
    },
]