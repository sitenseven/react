export const UserType = [
    {
        id: 'User',
        name: 'User'
    },
    {
        id: 'Provider',
        name: 'Provider'
    },
    {
        id: 'Organization',
        name: 'Organization'
    },
]